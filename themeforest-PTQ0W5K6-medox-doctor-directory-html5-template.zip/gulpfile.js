const tempaw = require( 'tempaw-functions' );

tempaw.init( `${process.cwd().replace( /\\/g, '/' )}/config.js` );
